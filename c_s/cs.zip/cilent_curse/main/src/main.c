/*****************************************************
copyright (C), 2014-2015, Lighting Studio. Co.,     Ltd. 
File name： main.c
Author：Jerey_Jobs    Version:0.1    Date:2015/1/18 
Description：客户端主程序
Funcion List:   int ban();
                int chat();
                int broad();
                int write_line(char *s);
                int read_line(FILE *fp,char *buf);
                int chat_record();
                int check_putin();
                int cpwd();
                char my_getch(void);
                int hi();
                int kick();
                int cilent_log();
                int log_menu();
                int logoff();
                int my_check_putin();
                int my_gettime();
                int my_strcmp(char *src,char *ptr);
                void *read_message(void *arg);
                int cilent_regist();
                int rid_people();
                int rname();
                int show();
                int win_init();
                int win_init_admin();
*****************************************************/

#include "../../include/myhead.h"

extern void *read_message(void *arg);

int main(int argc, char *argv[]) 
{ 
    win_ok = 0;              
    power = 0;
  
	struct sockaddr_in server_addr; 
	struct hostent *host; 

	if(argc!=2) 
	{ 
		fprintf(stderr,"Usage:%s hostname \a\n",argv[0]); 
		exit(1); 
	} 

    /*将传入参数转为标准模式*/
	if((host=gethostbyname(argv[1]))==NULL) 
	{ 
		fprintf(stderr,"Gethostname error\n"); 
		exit(1); 
	} 
   
    /* 调用socket函数创建一个TCP协议套接口 */
	if((sockfd=socket(AF_INET,SOCK_STREAM,0))==-1)          //TCP连接
	{ 
		fprintf(stderr,"Socket Error:%s\a\n",strerror(errno)); 
		exit(1); 
	} 

	bzero(&server_addr,sizeof(server_addr)); 	
    server_addr.sin_family=AF_INET;     
    server_addr.sin_port=htons(portnumber);  

    server_addr.sin_addr.s_addr=inet_addr(argv[1]); 

	if(connect(sockfd,(struct sockaddr *)(&server_addr),sizeof(struct sockaddr))==-1) 
	{ 
		fprintf(stderr,"Connect Error:%s\a\n",strerror(errno)); 
		exit(1); 
	} 

    pthread_t id;
	pthread_create(&id,NULL,(void *)read_message,(void *)&sockfd);

    int cmd = 0;         //检查输入返回值

    while(1)
	{
        /*若当前状态不是在线也不是被禁言 则进入登录界面*/
        if(msg.state != LINE && msg.state != CHAT_BAN)
        {
            log_menu();  

            cmd = my_check_putin();
        
            switch(cmd)
            {
                case LOG:cilent_log();break;
                case REGIST:cilent_regist();break;
            }    
        }
        /*若当前为在线状态 或者被禁言状态 而 权利为无特权 进入普通用户界面*/
        else if(((msg.state == LINE) || (msg.state == CHAT_BAN)) && (power == 0))
        {
            if(win_ok != 1)         //若未进入curse模式则进入
            {    
                win_init();
            }

            cmd = check_putin();
            
            switch(cmd)             //根据返回值执行对应的操作
            {
                case CHAT:chat();break;
                case BROAD:broad();break;
                case CPWD:cpwd();break;
                case RNAME: rname();break;
              //  case LOGOFF:logoff();break;
                case EXIT:  refresh();endwin();exit(1);break;
                case RECORD: chat_record();break;
                case END_RECORD: clear_chat();break;
                case SEND_FILE: send_file();break;
            }

        }

        /*若当前为在线状态且为特权状态 则调用管理员界面*/
        else if((msg.state == LINE) && (power == 1))
        {
            if(win_ok != 1)
            {    
                win_init_admin();
            }

            cmd = check_putin();

            switch(cmd)                //根据返回值执行对应的操作
            {
                case CHAT:chat();break;
                case BROAD:broad();break;
                case CPWD:cpwd();break;
                case RNAME: rname();break;
                case EXIT: refresh();endwin();exit(1);break;
                case KICK: kick();break;
                case BAN: ban();break;
                case RID_PEOPLE:rid_people();break;
                case RECORD: chat_record();break;
                case SEND_FILE: send_file();break;
                case END_RECORD: clear_chat();break;
                case ADS: admin_ads();break;
            }
        }
	}

	close(sockfd); 
	exit(0); 
} 
