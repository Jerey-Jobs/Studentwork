/*****************************************************
copyright (C), 2014-2015, Lighting Studio. Co.,     Ltd. 
File name：   check_putin.c
Author：Jerey_Jobs    Version:0.1    Date: 
Description： curses模式下 检测用户输入，并返回相应的宏定义
Funcion List: int check_putin()
*****************************************************/

#include "../../include/myhead.h"

/*************************************************
Function:       int check_putin()
Description:    curses模式下 检测用户输入的指令，并返回相应的宏定义
Calls:          NO
Called By:      main
Input:          NO
Return:             
*************************************************/ 
int check_putin()
{
    char check[MAX];
    
    setbuf(stdin,NULL);                        //清空输入缓冲
    
    /*先打印三行空格将scan窗口清空*/
    mvwprintw(scan_win, 1, 1, "                                                                ");
    mvwprintw(scan_win, 2, 1, "                                                                ");
    mvwprintw(scan_win, 3, 1, "                                                                ");
    wrefresh(scan_win); 
    mvwprintw(scan_win, 1, 1, " please input cmd :");
    wrefresh(scan_win);

    mvwprintw(show_win, 2, 8, "                ");
    mvwprintw(show_win, 2, 4, "[%10s]",msg.name);
    wrefresh(show_win);
    echo();

    memset(check,0,sizeof(check));
    wrefresh(scan_win);
    mvwscanw(scan_win,1,20,"%s",check);

    if(my_strcmp(check,"log") == 0)           
    {
        return LOG;
    }

    else if(my_strcmp(check,"regist") == 0)  
    {
        return REGIST;
    }

    else if(my_strcmp(check,"show") == 0)    
    {
        return SHOW;
    }

    else if(my_strcmp(check,"chat") == 0)    
    {
        return CHAT;
    }

    else if(my_strcmp(check,"broad") == 0)    
    {
        return BROAD;
    }

    else if(my_strcmp(check,"hi") == 0)   
    {
        return HI;
    }

    else if(my_strcmp(check,"cpwd") == 0)    
    {
        return CPWD;
    }

    else if(my_strcmp(check,"rname") == 0)    
    {
        return RNAME;
    }

    else if(my_strcmp(check,"logoff") == 0)   
    {
        return LOGOFF;
    }

    else if(my_strcmp(check,"exit") == 0)
    {
        return EXIT; 
    }

    else if(my_strcmp(check,"kick") == 0)     
    {
        return KICK; 
    }

    else if(my_strcmp(check,"ban") == 0)     
    {
        return BAN; 
    }
    else if(my_strcmp(check,"rid") == 0)     
    {
        return RID_PEOPLE; 
    }

    else if(my_strcmp(check,"record") == 0)   
    {
        return RECORD; 
    }
    
    else if(my_strcmp(check,"end") == 0)   
    {
        return END_RECORD; 
    }

    else if(my_strcmp(check,"send") == 0)    
    {
        return SEND_FILE; 
    }

    else if(my_strcmp(check,"y") == 0)      
    {
        return SEND_FILE; 
    }
   
    else if(my_strcmp(check,"ads") == 0)      
    {
        return ADS; 
    }

    else
    {
          wrefresh(scan_win);
    }

    return 0;

}
