#ifndef _MYHEAD_H_

#define _MYHEAD_H_

#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <fcntl.h>
#include <sqlite3.h>
#include <time.h>
#include <curses.h>
#include <locale.h>

#define portnumber 8000      //端口号8000

#define MAX 100
#define SHORT_LEN 20
#define MAX_LEN 48

#define CILENT_CHANGE -777

#include <termio.h>



enum CMD{
	LOG = -100,         //登陆
	REGIST,             //注册
	SHOW,          	    //显示在线人员
	CHAT,               //聊天
	BROAD,              //广播
	HI, 				//快捷表情
	CPWD,               //改密
	RNAME,              //改名
	LOGOFF,             //下线
	EXIT,               //退出
	KICK,               //踢人
	BAN,                //禁言
	RID_PEOPLE,         //解除禁言
	LINE,               //在线状态
	NOTLINE,            //不在线
	CHAT_BAN,           //被禁言状态
    LOG_OK,             //登陆成功
    REGIST_OK,          //注册成功
    CHAT_OK,            //聊天成功
    BROAD_OK,           //广播成功
    CPWD_OK,            //改密成功
    RNAME_OK,           //改密成功
    LOGOFF_OK,          //下线成功
    LEFT_MSG            //离线消息

};

enum B{
	YES = -1000,
	NOT_EXIST,          //用户不存在
	PASSWORD_ERROR,     //密码错误
	CHAT_NOT_EXIST,     //聊天对象不存在
	CHAT_NOTLINE,       //聊天对象不在线
	BAN_OK,             //禁言成功
	BAN_NOTLINE,        //禁言对象不在线
	BAN_NOTEXIST,       //禁言对象不存在
	KICK_OK,            //踢人成功
	KICK_NOTLINE,       //踢出对象不在线
	KICK_NOTEXIST,      //踢出对象不存在
	KICKED,             //被踢出
	BANED,              //被禁言
	RID_OK,             //解禁成功
	RIDED,              //被解除禁言
	RID_NOTLINE,
	RID_NOTEXIST,
	SHOW_OK,            
	SHOW_BACK,
	HI_OK,
	HI_1 = 100,
	HI_2,
	HI_3,
	HI_4,
	HI_5,
	HI_6,
	RECORD,           
	END_RECORD
};

enum send_q{ 
	SEND_FILE = -500,
	SEND_OK,
	SEND_NOT_EXIST,
	SEND_NOTLINE,
	RECIVE_YES,
	RECIVE_NOT,
	MULTI_NAME,            //名字已被占用
	ADS,
	ADS_OK,
	CLEAR_START = -200
};

struct message            //消息封装
{
    int action;
    char id[SHORT_LEN];
    char name[SHORT_LEN];
    char password[SHORT_LEN];
    char toname[SHORT_LEN];
    char msg[MAX];
    char file_name[SHORT_LEN];
    int state;
};


typedef struct message MSG;

MSG msg;

int sockfd;              //与服务器连接套接字

FILE *fp;                //聊天记录文件指针

int regist_back;         //注册返回

int line_show;           //在线用户窗口行指针

char c_time[20];         //存放当前时间

int win_ok;              //是否进入curses模式判断
int power;               //管理员判断
int send_judge;          //发送文件

int clear_flag;

char ads_buf[MAX];

/*curses模式下的7个窗口指针*/
WINDOW *log_win;         
WINDOW *show_win;
WINDOW *chat_win;
WINDOW *chat_box_win;
WINDOW *scan_win;
WINDOW *help_win;
WINDOW *line_win;
WINDOW *tips_win;

int ban();
int chat();
int broad();
int write_line(char *s);
int read_line(FILE *fp,char *buf);
int chat_record();
int check_putin();
int cpwd();
char my_getch(void);
int hi();
int kick();
int cilent_log();
int log_menu();
int logoff();
int my_check_putin();
int my_gettime();
int my_strcmp(char *src,char *ptr);
void *read_message(void *arg);
int cilent_regist();
int rid_people();
int rname();
int show();
int win_init();
int win_init_admin();
int clear_chat();
int clear_show();
int send_file();
int my_getns(char *str,int n);

#endif
