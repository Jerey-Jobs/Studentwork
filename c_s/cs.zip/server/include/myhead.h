#ifndef _MYHEAD_H_
#define _MYHEAD_H_

#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <pthread.h>
#include <fcntl.h>
#include <sqlite3.h>

#define portnumber 8000

#define MAX 1000

#define CILENT_CHANGE -777

enum CMD{
	LOG = -100,        //
	REGIST,
	SHOW,
	CHAT,
	BROAD,
	HI,
	CPWD,
	RNAME,
	LOGOFF,
	EXIT,
	KICK,
	BAN,
	RID_PEOPLE,
	LINE,
	NOTLINE,
	CHAT_BAN,
	LOG_OK,
    REGIST_OK,
    CHAT_OK,
    BROAD_OK,
    CPWD_OK,
    RNAME_OK,
    LOGOFF_OK,
    LEFT_MSG
};

enum B{
	YES = -1000,
	NOT_EXIST,
	PASSWORD_ERROR,
	CHAT_NOT_EXIST,
	CHAT_NOTLINE,
	BAN_OK,
	BAN_NOTLINE,
	BAN_NOTEXIST,
	KICK_OK,
	KICK_NOTLINE,
	KICK_NOTEXIST,
	KICKED,
	BANED,
	RID_OK,
	RIDED,
	RID_NOTLINE,
	RID_NOTEXIST,
	SHOW_OK,
	SHOW_BACK,
	HI_OK,
	HI_1 = 100,
	HI_2,
	HI_3,
	HI_4,
	HI_5,
	HI_6,
};

enum send_q{ 
	SEND_FILE = -500,
	SEND_OK,
	SEND_NOT_EXIST,
	SEND_NOTLINE,
	RECIVE_YES,
	RECIVE_NOT,
	MULTI_NAME,
	ADS,
	ADS_OK
};

struct message
{
    int action;
    char id[20];
    char name[20];
    char password[20];
    char toname[20];
    char msg[100];
    char file_name[20];
    int state;
};

struct people
{
    int fd;
    char name[20];
    char id[20];
    char password[20];
    int state;
    struct people *next;
};


struct unread
{
	char name[20];
	char toname[20];
	char msg[100];
	struct unread *next;
};


typedef struct message MSG;

typedef struct people NODE;
typedef struct people * LINK;

typedef struct unread UNREAD;

LINK head;
UNREAD *uhead;


int my_strcmp(char *src,char *ptr);
int ban(int fd,MSG buf);
int broad(int fd,MSG buf);
int change_name(int fd,MSG buf);
int change_password(int fd,MSG buf);
int left_msg(MSG buf);
int chat(int fd,MSG buf);
int admin_ads(int fd,MSG buf);
int check_hi(char *src);

int check_hi(char *src);
int init();
int kick(int fd,MSG buf);
int check_people(char *id,char *password);
int find_name(char *id,char *name);
int login(int fd,MSG buf);
int logoff(int fd,MSG buf);
void my_read_message(int fd,MSG buf);
int my_itoa(int num,char *str);
int regist(int fd,MSG buf);
int rid_people(int fd,MSG buf);
int send_file(int fd,MSG buf);
int show_people(int fd,MSG buf);
int write_to_db(LINK buf);

#endif
